import { StrategyDetailPage } from "@/components/strategy/strategy-detail-page"

export default function Page() {
  return <StrategyDetailPage />
}
