import { DashboardLayout } from "@/components/dashboard/dashboard-layout"

export default function DashboardPage() {
  return <DashboardLayout />
}
