import { MarketplacePage } from "@/components/marketplace/marketplace-page"

export default function Page() {
  return <MarketplacePage />
}
